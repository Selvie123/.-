# Hospital Risk Alert System

This project uses a machine learning model to classify hospital patients as high-risk and send alerts.

## Features
- Input: CSV with patient records
- ML Model: Random Forest
- GUI: Streamlit interface
- Alerts: Email/SMS if patient is high-risk
- Data Storage: Save records in CSV/Database